/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_233(unsigned x)
{
    return x + 3347663008U;
}

unsigned getval_131()
{
    return 2421734945U;
}

void setval_270(unsigned *p)
{
    *p = 2462550344U;
}

void setval_437(unsigned *p)
{
    *p = 3347671214U;
}

unsigned addval_481(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_200(unsigned x)
{
    return x + 2421710497U;
}

void setval_484(unsigned *p)
{
    *p = 3281293400U;
}

unsigned addval_346(unsigned x)
{
    return x + 2438496422U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_251(unsigned x)
{
    return x + 3268315521U;
}

void setval_121(unsigned *p)
{
    *p = 3525889673U;
}

unsigned addval_490(unsigned x)
{
    return x + 3221278345U;
}

void setval_202(unsigned *p)
{
    *p = 1103610505U;
}

unsigned getval_390()
{
    return 3675832969U;
}

unsigned addval_499(unsigned x)
{
    return x + 3531918985U;
}

unsigned addval_185(unsigned x)
{
    return x + 2428668190U;
}

void setval_238(unsigned *p)
{
    *p = 3682914699U;
}

void setval_476(unsigned *p)
{
    *p = 3281047937U;
}

unsigned getval_191()
{
    return 3687109001U;
}

void setval_182(unsigned *p)
{
    *p = 3372798345U;
}

unsigned getval_125()
{
    return 3286270280U;
}

void setval_272(unsigned *p)
{
    *p = 3250751866U;
}

void setval_262(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_312(unsigned x)
{
    return x + 3374371209U;
}

unsigned getval_286()
{
    return 2425409928U;
}

unsigned getval_252()
{
    return 2430632264U;
}

unsigned getval_327()
{
    return 3286272329U;
}

void setval_243(unsigned *p)
{
    *p = 3281047181U;
}

unsigned getval_462()
{
    return 2497743176U;
}

void setval_104(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_300(unsigned x)
{
    return x + 2447411528U;
}

void setval_427(unsigned *p)
{
    *p = 3675832969U;
}

unsigned addval_444(unsigned x)
{
    return x + 3531915913U;
}

void setval_425(unsigned *p)
{
    *p = 3374370445U;
}

unsigned getval_355()
{
    return 3378561673U;
}

unsigned addval_409(unsigned x)
{
    return x + 3224424841U;
}

void setval_141(unsigned *p)
{
    *p = 3264269961U;
}

void setval_429(unsigned *p)
{
    *p = 3223375497U;
}

void setval_231(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_377()
{
    return 3224945288U;
}

unsigned getval_142()
{
    return 3281047977U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
